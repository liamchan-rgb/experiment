Layered P1 downward walk prototype

Import each numbered PNG sequence as one image level in OpenToonz or Tahoma2D.
All sequences contain 24 aligned 256x256 RGBA frames for one walk cycle.
Use Legs, Boots (or BlueBoots), then Body, from back to front.
Reference is the exact existing game pose and can be used as a guide layer.
BlueVariant is a precomposed shoe colorway example.
Reassembled shows the grouped-layer result; the app atlas instead preserves per-frame segment depth order.

BlueVariant-Atlas is also packed into the app for the gait-test comparison preview.
The regular map characters still use their existing full-pose atlases.
OpenToonz/Tahoma2D GUI import was not run in the headless build workspace.
