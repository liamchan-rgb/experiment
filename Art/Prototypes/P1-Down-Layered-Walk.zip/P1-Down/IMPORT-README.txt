Layered P1 downward walk prototype

Import each numbered PNG sequence as one image level in OpenToonz or Tahoma2D.
All sequences contain 24 aligned 256x256 RGBA frames for one walk cycle.
Use Legs, Boots (or BlueBoots), then Body, from back to front.
Reference is the exact existing game pose and can be used as a guide layer.
BlueVariant is a precomposed shoe colorway example.

This is an offline art prototype; the app still uses its existing full-pose atlas.
OpenToonz/Tahoma2D GUI import was not run in the headless build workspace.
