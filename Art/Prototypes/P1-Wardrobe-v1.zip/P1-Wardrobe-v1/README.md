# P1 wardrobe source bundle v1

Open Art/Templates/P1-Wardrobe/down/v1/walk.gif for the normal 120ms preview,
or poses.png for idle00 + walk01-08. No HTML execution is needed.

Install Python3 dependencies with `python3 -m pip install -r requirements.txt`.
Run `python3 scripts/test-character-compositor.py` for 19 integration checks.

Assemble the actual parts with the unchanged generic compositor:

```sh
python3 scripts/compose-character-parts.py \
  --catalog Art/Templates/P1-Wardrobe/down/v1/catalog.json \
  --motion Art/Templates/P1-Wardrobe/down/v1/motion.json \
  --base p1-neutral-down-walk-r2 \
  --asset p1-hair-chestnut-v1 --asset p1-face-blue-v1 \
  --asset p1-outfit-forester-v1 --asset p1-weapon-short-sword-v1 \
  --direction down --out /tmp/p1-wardrobe
```

The common body r2 only reassigns48 pixels in frame07 to their anatomical leg.
Its nine body composites are pixel-identical to the approved r1. All24 new
combinations use r2; no appearance chooses a separate body. Motion changes
only its pinned base manifest SHA; pose geometry/order and engine are unchanged.

The heads and original neutral poses were user approved. The new outfit and
sword await art review. One down direction, one outfit and one sword do not
constitute a complete eight-direction game wardrobe.

The bundle includes raw sources/prompts, editable ORA/SVG, runtime PNGs,
manifests, all216 outputs and review tools. Full older body-generation and
direction-review history remains in the repository. Full historical protection
checks in validate-wardrobe-review.py require that complete repository.

See Art/Templates/P1-Wardrobe/down/v1/README.md for the Chinese detailed report.
