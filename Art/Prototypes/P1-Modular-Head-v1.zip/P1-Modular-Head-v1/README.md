# P1 独立头部换装 v1

直接查看 Art/Templates/P1-Modular/down/v1/walk.gif（正常速度）、heads.png（头部放大）及 independent-parts.png（独立部件）。完整说明见该目录 README.md。

本包包含固定底模、三款头发、两款五官、当前头部全部工具源稿／修订、ORA／SVG、合同和装配工具。当前头部美术待审；衣物武器和其他中性方向尚未完成。人体较早的完整制作历史及未附带的历史讨论链接，见 https://github.com/liamchan-rgb/experiment/tree/feat/layered-living-scene 。

安装 Python 3 及 requirements.txt 中依赖，在本目录运行：

```sh
python3 scripts/test-character-compositor.py
python3 scripts/compose-character-parts.py --catalog Art/Templates/P1-Modular/down/v1/catalog.json --motion Art/Templates/P1-Modular/down/v1/motion.json --base p1-neutral-down-walk-r1 --asset p1-hair-teal-crop-v1 --asset p1-face-blue-v1 --direction down --out output
```

iPad 可直接查看 PNG／GIF，无须运行本地 HTML；编辑源文件和脚本需相应软件环境。下载包只含正常速度 GIF。
