# 强效治疗特效 — 接入说明

## 资源简介
- 风格：高清像素混合（HD pixel-art hybrid），翠绿/翡翠绿/薄荷青与白绿色高光。
- 内容：20 帧强效治疗能量动画；包含能量汇聚、双层环形波纹、向上喷涌的生命光丝、菱形粒子/叶片光片/十字星芒，以及回流消散。
- 单帧：512 × 512 px，RGBA PNG，透明背景。
- 精灵表：2560 × 2048 px，5 列 × 4 行；无帧间留白、无额外边距。
- 文件名：`healing_strong_01.png` 至 `healing_strong_20.png`。

## 每帧划分规则
精灵表按**从左到右、从上到下**排列，索引从 1 开始：

- 第 1 行：帧 01–05
- 第 2 行：帧 06–10
- 第 3 行：帧 11–15
- 第 4 行：帧 16–20

每格严格为 512 × 512 px。对 1-based 帧号 `n`：
- `col = (n - 1) % 5`
- `row = floor((n - 1) / 5)`
- 像素裁切矩形：`x = col * 512, y = row * 512, width = 512, height = 512`

若引擎的 UV 原点在左下角，读取精灵表时需要按引擎约定翻转 V 坐标；单帧 PNG 不涉及此问题。

## 动画节奏建议
- 建议先按 20 FPS 播放，完整时长约 1 秒；也可在 16–24 FPS 范围内调整。
- 帧 01–04：能量核出现、粒子向中心汇聚。
- 帧 05–10：第一层波纹展开，第二层出现，光丝开始上涌。
- 帧 11–14：峰值段；双环、白绿色核心、上涌光丝和粒子同时最强。
- 帧 15–19：外环淡出，粒子回流，核心收束。
- 帧 20：极淡余辉。播放完毕后销毁特效对象或将整体 Alpha 设为 0，确保完全透明。

## 接入建议
- **Unity**：将精灵表导入为 Sprite，Sprite Mode 设为 Multiple，使用 Sprite Editor 按 512 × 512 网格切片；建议关闭 Mip Maps、关闭有损压缩，Filter Mode 选 Point（像素簇需要更锐利时）。也可直接将 `frames/` 中的 20 张 PNG 逐帧加载。
- **Godot**：使用 SpriteFrames/AnimatedSprite2D；若从精灵表读取，设置 Hframes = 5、Vframes = 4、Frame 数 = 20，Region/帧尺寸为 512 × 512。
- **通用 UV 伪代码**（帧索引从 0 开始）：

```text
col = frameIndex % 5
row = floor(frameIndex / 5)
u0 = col / 5
v0 = row / 4
uSize = 1 / 5
vSize = 1 / 4
```

部分引擎的 V 轴方向相反，按引擎纹理坐标系调整即可。

## 治疗量与播放规则
先按目标生命上限结算实际恢复量，再选择特效档位：

```text
actualHeal = max(0, min(targetMaxHP, oldHP + requestedHeal) - oldHP)
if actualHeal <= 0:
    不播放治疗特效
else:
    tier = classifyByActualHeal(actualHeal)  # 使用游戏配置中的档位阈值
    播放对应档位；本资源包提供 strong 档
```

档位阈值由游戏数值配置决定，本包不假设固定 HP 数值。若治疗被生命上限截断，必须使用截断后的 `actualHeal` 判档。
